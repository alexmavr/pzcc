package misc;

# misc.pm
#
# [ldasm] Miscellaneous routines
#

use strict;
use Tk;
use Tk::Text;
use Tk::Dialog;
use Tk::DialogBox;
use Tk::Toplevel;
use Tk::FileSelect;

use winMain;

#-------
# Export

use Exporter;
use vars qw(@ISA @EXPORT);
@ISA = qw(Exporter);
@EXPORT = qw(&FixWindowManagerBug
             &MsgBox &ErrBox &ClientWin &TextTags &FileSelDlg);

#----------------------
# FixWindowManagerBug()
#
# Most window-managers have a huge bug (see also "BUGS" in Tk::wm.pod), so the
# window has to be withdrawn (unmapped) and the remapped (using deiconfy).
# I also store and restore the window-geometry.
# Doesn't look pretty, but it seems t be the only solution.

sub FixWindowManagerBug()
{
	if ($main::cfg->Get('WMFix') eq 'on') {
		my $wgeo = $winMain::win->geometry();
		$winMain::win->withdraw();
		$winMain::win->deiconify();
		$winMain::win->geometry($wgeo);
	}
}

#----------
# MsgBox($)
#
# Shows a MessageBox
#
# in:  Message
# out: undef = Cancel

sub MsgBox($)
{
   my $msg = shift;

   my @msgBtn = ($main::langStr{'CANCEL'},'OK');
   my $msgdlg = $winMain::win->DialogBox(
      -title   => $main::langStr{'MESSAGE'},
      -buttons => [@msgBtn],
      -default_button => $msgBtn[1]
   );
   $msgdlg->add('Label',
      -text => $msg
   )->pack();

   return ($msgdlg->Show() eq $msgBtn[0]) ? undef : 1;
}

#----------
# ErrBox($)
#
# A error occured, show a small dialog
#
# in:  Message
# out: -

sub ErrBox($)
{
   my $msg = shift;

   $winMain::win->Dialog(
      -title => $main::langStr{'ERROR'}.'!',
      -text  => $msg
   )->Show();
}

#--------------
# ClientWin(%)
#
# Creates a invisible toplevel-widget with buttons
#
# in:  Optionsref (like "DialogBox")
# out: Toplevel-reference

sub ClientWin($%)
{
   my %cwopt = @_;

   # The toplevel
   my $top = $winMain::win->Toplevel(
      -title => $cwopt{'-title'}
   );
   $top->withdraw();
   $top->protocol('WM_DELETE_WINDOW' => sub { $top->withdraw(); });

   # Buttons
   my $btnFrame = $top->Frame()->pack(
      -side   => 'bottom',
      -anchor => 'e'
   );
   if (!exists $cwopt{'-buttons'}) {
      $btnFrame->Button(
         -text    => 'OK',
         -command => sub { $top->withdraw(); }
      )->pack(
         -side => 'left'
      );
   } else {
      foreach(keys %{$cwopt{'-buttons'}}) {
         $btnFrame->Button(
            -text    => $_,
            -command => $cwopt{'-buttons'}->{$_}
         )->pack(
            -side => 'left'
         );
      }
   }

   return $top;
}

#-------------
# TextTags($$)
#
# Configures tags for a textbox
#
# in:  Text-reference, Fontgroup (configuration)
# out: -

sub TextTags($$)
{
   my ($txt,$fntname) = @_;

   # Configure
   my %tagPriority;
   my $fnt = $main::cfg->Get($fntname);
   foreach(keys %{$fnt}) {
      $txt->tagConfigure($_,
         foreground => $fnt->{$_}->{'col'} || 'black',
         background => $fnt->{$_}->{'bg'}  || $txt->cget('-bg'),
         underline  => $fnt->{$_}->{'ul'}  || 'n',
         justify    => $fnt->{$_}->{'aln'} || 'left',
         lmargin1   => $fnt->{$_}->{'lm'}  || 0,
         font       => $fnt->{$_}->{'fnt'} # no default!
      );
      push(@{$tagPriority{$fnt->{$_}->{'prior'} || 0}},$_);
   }

   # Tag priority
   for my $pk(sort {$a <=> $b} keys %tagPriority) {
      for (@{$tagPriority{$pk}}) {
         $txt->tagRaise($_);
      }
   }
}

#----------------
# FileSelDlg(%)
#
# Creates a dummy-toplevel for the FileSelect-dialog.
#
# in:  FileSelect-options.
# out: Filename or undef

sub FileSelDlg(%)
{
	my %fsOpts = @_;

	my $ttl = $winMain::win->Toplevel();
	$ttl->withdraw();
	my $todlg = $ttl->FileSelect(
		%fsOpts,
		-takefocus => '1',
		-create => "1"
	);
	$ttl->grab();
	my $fname = $todlg->Show();
	$ttl->grabRelease();
	$ttl->destroy;

   FixWindowManagerBug();

	return $fname;
}


1;

