package asmps;

#
# asmps.pm
#
# [ldasm] Processes the objdump-output
#

use strict;
use Data::Dumper;
use Tk::Text;
use File::Basename;

use winMain;
use winDlg;
use misc;

#-------
# Export

use Exporter;
use vars qw(@ISA @EXPORT %refsType);
@ISA = qw(Exporter);
@EXPORT = qw(&CreateListing &ListingToProject &ProjectToListing
             &IsCodeAddr &GetSectionRow);

#----------------
# Global variable

my (%sections,%refsAddr);

#-----------------------
# _ReadStaticSections(*)
#
# Reads the details of the static sections
#
# in:  Filehandle
# out: -

sub _ReadStaticSections(*)
{
   local *FH = shift;

   # Skip rows until section-table
   my $line;
   while ($line = <FH>) {
      last if ($line =~ /^Idx Name/);
   }

   # Read in sections
   while ($line = <FH>) {
      my @secdet = split(/\s+/,$line);
      last if (@secdet != 8); # Section end
      $line = <FH>;
      $sections{$secdet[2]} = {
         # Specs
         'size'    => hex $secdet[3],
         'vma'     => hex $secdet[4],
         'vma_end' => hex($secdet[4])+hex($secdet[3]),
         'lma'     => hex $secdet[5],
         'fileofs' => hex $secdet[6],
         # attibutes
         'type'    => ($line =~ /DATA/) ? 'data' : ($line =~ /CODE/) ? 'code' : '?',
         'ro'      => ($line =~ /READONLY/) ? 1 : undef
      }
   }
}

#-----------------
# _ReadStrings($)
#
# Reads all string from the ReadOnly-data-section
# Note: "_ReadStaticSections" must be executed before
#
# in:  filename of the executable
# out: -

sub _ReadStrings($)
{
   my $orgFName = shift;

   # Convert section-details into real numbers
   my $strSize    = $sections{'.rodata'}->{size};
   my $strFileOfs = $sections{'.rodata'}->{fileofs};
   my $strVMA     = $sections{'.rodata'}->{vma};

   # Read .rodata
   open(ROD,"< $orgFName");
   seek(ROD,$strFileOfs,0);
   read(ROD,my $strData,$strSize);
   close(ROD);

   # Split .rodata into strings/hash
   foreach(split(/\x00/,$strData)) {
      if ($_ gt '') {
          my $rcVMA = sprintf('%x',$strVMA);
          $refsAddr{$rcVMA}->{'str'} = $_;
          chomp($refsAddr{$rcVMA}->{str});
      }
      $strVMA += length($_)+1;
   }
}

#-------------------------
# _ReadSymbolTable(*)
#
# Extracts all functions from the symbol table(s)
# Note: Filepointer must be right after the section-table
#
# in:  Filehandle
# out: -

sub _ReadSymbolTable(*)
{
   local *FH = shift;

   # Read all everything
   while (my $line = <FH>) {
      last if ($line =~ /^Disassembly/);
      chomp($line);
      next if ($line !~ /([^ ]+).{7}(.).(.+?)\t.+? (.+)/);

#      print "'$1' ('$2') '$3' '$4'\n";
		if ($1 ne '00000000') {
			# Reformat function-name
			my $raddr = $1; # store temporary since its killed by the following patterns
			my $rexp  = $2;
			my $rtype = $3;
			my $rfct  = $4;
			$rfct =~ s/^\s+//;
			$rfct =~ s/\s+/::/;

			# Insert into reference-hash
         if ($rtype eq '*UND*') {
            $refsAddr{$raddr}->{'import'} = $rfct;
         } elsif ($rtype eq '.text') {
            $refsAddr{$raddr}->{'internal'} = $rfct;
            $refsAddr{$raddr}->{'export'} = $rfct if ($rexp eq 'F');
         }
      }
   }
}

#-----------------------
# _SearchCallAndJumps(*)
#
# Searchs the jumps and calls from the disassembly
#
# in:  Filehandle
# out: -
#
sub _SearchCallAndJumps(*)
{
   local *FH = shift;

   my $i = 0;
   while (my $line = <FH>) {
#      $i++;
#      last if ($i == 20);

      next if (($line !~ /^0/) || ($line !~ /\s{2,}j|call/));
      next if ($line !~ /(0x)?([^ ]+).+?\s{2,}([^ ]+)\s+\*?(0x)?([0-9a-f]+)( |\n)/);
      my ($sjaddr,$op,$daddr) = ($2,$3,$5);
      if ($op eq 'call') {
         push(@{$refsAddr{$daddr}->{call}},$sjaddr);
      } else {
         my $fjl = "$sjaddr(".(($op eq 'jmp') ? 'U' : 'C').')';
         push(@{$refsAddr{$daddr}->{jump}},$sjaddr);
      }
   }
}

#------------------
# _FormatAsmLine($)
#
# in:  Line (ok call it row if you want to), all mnemonics with size-character
# out: Addr,opcode-bytes,mnemonic,opdata1,opdata2
#      Addr=undef if no valid asm

sub _FormatAsmLine($$)
{
   my ($line, $sizeChar) = @_;

   # Split the whole line
   return if ($line !~ /(0x)?([0-9a-f]+)( <[^>]+>)?(( [0-9a-f]{2})+)\s+([^ ]+)(\s+([^ ]+))?/);
   my $opAddr     = $2;
   my $opBytes    = $4;
   my $opMnemonic = $6;
   my $opData     = $8;

#   print "** ", $line, "\n";
#   print "- Addr: ", $opAddr, "\n"; 
#   print "- Byte: ", $opBytes, "\n";
#   print "- Mne:  ", $opMnemonic, "\n";
#   print "- Data: ", $opData, "\n\n";
 
   # Remove spaces from opcode-bytes
   $opBytes =~ s/\s//g;

   # Single opcode - then return
   return ($opAddr,$opBytes,$opMnemonic) if ($opData eq undef);

   # Remove and convert some stuff
   $opData =~ s/%|\$//g;                             # remove "%" and "$"
   $opData =~ s/0xffffff([\da-f]{2})/hex($1)-256/ge; # 0xffffffxx -> -xx
   $opData =~ s/0x(\d[^\da-f])/$1/g;                 # 0x0..0x9 -> 0..9
   $opData =~ s/0x//g;                               # Remove "0x"

   # Rearrange if not a call or jump
   if ($opMnemonic !~ /call|j.*/) {
      # Define datasize
      my $dataSize = '';
      if ($sizeChar) {
         my %SizeNames = ('b' => 'byte ','w' => 'word ','l' => 'dword ');
        
         $dataSize = $SizeNames{substr($opMnemonic,-1,1)};
         substr($opMnemonic,-1,1) = '';
      }

      # Split opcode-data and convert into intel-order
      if ($opData =~ /,/) {
         # Split
         $opData =~ /(.*?)(\((.+?)\))?,([^\(]*)(\(([^\)]+)\))?/;
         my (@opv,@opi);
         ($opv[1],$opi[1],$opv[0],$opi[0]) = ($1,$3,$4,$6);

         # Combine
         my @opcomb;
         for my $i(0..1) {
            if ($opi[$i] ne undef) {
               # Handle content of brances
               my @dtc = split(/,/,$opi[$i]);
               $opcomb[$i] = "${dataSize}ptr [$dtc[0]";
               if (@dtc == 3) {
                   $opcomb[$i] .= ($dtc[2] != 1) ? "+$dtc[2]*$dtc[1]" : "*$dtc[1]";
               } elsif (@dtc == 2) {
                  $opcomb[$i] .= "*$dtc[1]" if ($dtc[1] != 1);
               }

               # Add stuff before braces
               if (($opv[$i] eq undef) || ($opv[$i] == 0)) {
                  $opcomb[$i] .= ']';
               } else {
                  $opcomb[$i] .= (($opv[$i] > 0) ? '+' : '')."$opv[$i]]";
               }
            } else {
               $opcomb[$i] = $opv[$i];
            }
         }
         return ($opAddr,$opBytes,$opMnemonic,$opcomb[0],$opcomb[1]);

      # nothing to split
      } else {
         if ($opData =~ /([^\(]+)\(([^\)]+)\)/) {
            $opData = "${dataSize}ptr [$2".(($1 eq undef) ? ']' : "+$1]");
         } elsif ($opData =~ /\+/) {
            $opData = "${dataSize}ptr [$opData]";
         }
      }

   # Remove * from the jumps/calls
   } else {
      $opData =~ s/^\*//;
   }

   return ($opAddr,$opBytes,$opMnemonic,$opData);
}

#-----------------
# _RefsOutput($\%)
#
# Prints the whole refsXXX-hash (for development only)
#
# in+out: -

sub _RefsOutput($\%)
{
   my ($desc,$rhr) = @_;

   print "*** Output : $desc ***\n\n";
   foreach my $ad(keys %{$rhr}) {
      print "$ad:\n";
      foreach (keys %{$rhr->{$ad}}) {
         print "   $_\t= ";
         if (ref $rhr->{$ad}->{$_} eq 'ARRAY') {
            print "'@{$rhr->{$ad}->{$_}}'\n";
         } else {
            print "'$rhr->{$ad}->{$_}'\n";
         }
      }
   }
}

#--------------------------------------------------------------
# _WriteNormal($), _WriteFunc($), _WriteStr($), _WriteExport($)
#
# Wrapper-functions for output.
# May modified to support STDOUT.
#
# in:  String
# out: -

sub _PrintNormal($)   { $winMain::text->insert('end',$_[0],'normal');   }
sub _PrintFunc($)     { $winMain::text->insert('end',$_[0],'function'); }
sub _PrintStr($)      { $winMain::text->insert('end',$_[0],'string');   }
sub _PrintInternal($) { $winMain::text->insert('end',$_[0],'internal'); }
sub _PrintProgress($) { $Progress{text}->insert('end',$_[0],'normal');
                        $Progress{text}->idletasks(); }

#---------------
# _AddSection($)
#
# Code-section
#
# in:  Row
# out: Section-name (for progress)

sub _AddSection($)
{
   my $row = shift;

   # Print
   $row =~ /(\.\w+):/;
   _PrintNormal "\n//".('*'x15)." section $1 ".('*'x15)."\n\n";

   # Add row
   $sections{$1}->{'row'} = $winMain::text->index('insert');

   return $1;
}

#--------------
# _AddRefBy($$)
#
# A address referenced by others
#
# in:  Description, reference-list
# out: -

sub _AddReferencedBy($$)
{
   my ($rdesc,$reflist) = @_;

   # Description
   _PrintNormal "\nReferenced by a $rdesc at Address:";

   # Print references
   my $refnum = 0;
   for (@{$reflist}) {
      if ($refnum % 5 == 0) {
         _PrintNormal "\n| ";
      } else {
         _PrintNormal ", ";
      }
      _PrintNormal ":$_";
      $refnum++;
   }
   _PrintNormal "\n|\n";

   # Update %refsType
   my $curRow = $winMain::text->index('insert');
   for (@{$reflist}) {
      $refsType{'ref'}->{$_} = $curRow;
   }
}

#------------------
# _AddExportRef($$)
#
# Start of a internal function
#
# in:  func-Name,addr
# out: -

sub _AddExportRef($$)
{
   my ($funcName,$addr) = @_;

   if (exists $refsAddr{$addr}->{'export'}) {
      _PrintInternal "Exported fn(): $funcName\n";
      $refsType{'export'}->{$funcName} = $winMain::text->index('insert');
   } else {
      _PrintInternal "Function(): $funcName\n";
   }
}

#---------------------
# _AddRefToFunc($$$)
#
# Reference to a internal or imported function
#
# in:  Functionname,addr,funcType-str
# out: -

sub _AddRefToFunc($$$)
{
   my ($funcName,$addr,$funcType) = @_;

   # Beauty as it should be ;-)
   my $frbeauty = (length $funcName <= 16) ? ('-'x(16-length $funcName)).'.' : '';
   _PrintFunc("\n* Reference To: $funcName $frbeauty\n"
              .(' 'x33)."|\n");

   # Add to %refName
   push(@{$refsType{$funcType}->{$funcName}},$winMain::text->index('insert'));
}

#------------------
# _AddStringRef($$)
#
# String (.rodata) reference.
#
# in:  String, addr
# out: -

sub _AddStringRef($$)
{
   my ($orgstr,$addr) = @_;

   # Convert some chars
   $orgstr =~ s/\n/\\n/;

   # Split
   my ($MinLen,$MaxLen,$MaxRow) = (30,40,4);

   _PrintStr "\n* Possible StringData Ref from Code Obj ";
   my $crow = 1;
   while ($orgstr =~ /((.{$MinLen,$MaxLen} )|(.{$MaxLen})|(.+$))/g) {
      _PrintStr ' 'x40 if ($crow > 1);
      _PrintStr "->\"$1\"\n";
      last if ($crow++ == $MaxRow);
   }
   _PrintStr ((' 'x33)."|\n");

   # Add entry into %refsType
   $orgstr =~ /(.{1,60})/;
   push(@{$refsType{'str'}->{$1}},$winMain::text->index('insert'));
}

#---------------------
# _RefsTypeToDialogs()
#
# Insert all %refsType-entries in the toplevel-reference-dialogs
#
# in+out: -

sub _RefsTypeToDialogs()
{
   my %tlh = (
      'import'   => \%FuncImport,
      'export'   => \%FuncExport,
      'internal' => \%FuncInternal,
      'str'      => \%StringRefs
   );

   while (my ($rname,$widr) = each(%tlh)) {
      $widr->{listbox}->insert('end',sort keys %{$refsType{$rname}});
   }
}

#----------------
# CreateListing($)
#
# Calls objdump, formats the output and writes it into the text-widget
#
# in:  Executable
# out: -

sub CreateListing($)
{
   my $execFname = shift;

   _PrintProgress "\n*** Create Listing ***\n\n";
   # Create objdump-output
   _PrintProgress "Calling objdump...\n";
	# Temp-name
	my $tmpSuffix = '';
	for (my $tmpCounter = 0; $tmpCounter < 5; $tmpCounter++) {
		$tmpSuffix .= chr(int(rand(25)+98));
	}
	my $tmpBase = basename($execFname);
	my $tmpName = "/tmp/LDasm.$$.$tmpBase.$tmpSuffix.tmp";
	# Execute objdump
   my $ErrorOutput = '~/.LDasm_error.txt';
   my $odCmd = 'objdump'
      .' -d'                 # Disassembly only code
      .' -T'                 # Dynamic symbol table
      .' -x'                 # All header informations
      .' --prefix-addresses' # Complete address
      .' --show-raw-insn'    # Opcode bytes
      .' -C'                 # Decode low-level-symbols (e.g. C++)
      ." $execFname"
      ." > $tmpName"
      ." 2>$ErrorOutput";

   my $status = system($odCmd);
   if ($status != 0) {
      ErrBox("Problems with objdump : $?\n"
            ."STDErr-output: '$ErrorOutput'");
      return;
   } else {
      unlink($ErrorOutput);  # Remove STDErr-file
   }

   # Read header (sections+references)
   (%sections,%refsType) = (undef,undef);
   open(FH,"< $tmpName") or do {
      ErrBox("Could�t open the temporary file");
      return;
   };

   _PrintProgress "Reading header...\n";
   _ReadStaticSections(*FH);
   _ReadStrings($execFname);
   _ReadSymbolTable(*FH);
   _SearchCallAndJumps(*FH);
#   _RefsOutput('refsAddr',%refsAddr);
#   close FH;
#   return;


   # Ouput the header, unfiltered
   _PrintProgress "Process assembler-listing:\n"
                 ."- Unfiltered output of the header\n";
   seek(FH,0,0);
   my $line;
   while ($line = <FH>) {
      if ($line =~ /^Disassembly/) {
         _AddSection($line);
         last;
      }
      _PrintNormal $line;

   }

   # Format disassembly
   my $objdumpSize = ($main::cfg->Get('OBJDumpSize') =~ /^yes$/i) ? 1 : 0;
   printf $objdumpSize, "\n";
   
   while ($line = <FH>) {
      chomp($line);
      my ($addr,$bc,$mne,$od1,$od2) = _FormatAsmLine($line, $objdumpSize);

      # Section-description
      if ($addr eq undef) {
         my $secname = _AddSection($line);
         _PrintProgress "- Section '$secname'\n";
      } else {
         # Referenced by...
         if (exists $refsAddr{$addr}) {
            my $rfa = $refsAddr{$addr};
            _AddReferencedBy('Call',$rfa->{'call'}) if (exists $rfa->{'call'});
            _AddReferencedBy('(U)nconditional or (C)onditional Jump',
                  $refsAddr{$addr}->{'jump'})
               if (exists $rfa->{'jump'});
            _AddExportRef($rfa->{'internal'},$addr) if (exists $rfa->{'internal'});
         }
         # Reference to...
         my $cra = ($od2 !~ /(^|\[)([0-9a-f]{4,})($|\])/) ? $od1 : $2;
         if (exists $refsAddr{$cra}) {
            my $rfa = $refsAddr{$cra};
            if (exists $rfa->{'str'}) {
               _AddStringRef($rfa->{'str'},$addr);
            } elsif (exists $rfa->{'import'}) {
               _AddRefToFunc($rfa->{'import'},$addr,'import');
            } elsif (exists $rfa->{'internal'}) {
               _AddRefToFunc($rfa->{'internal'},$addr,'internal');
            }
         }

         # OK the asm-code
         my $outAsm = sprintf(":%-8s %-22s ",$addr,$bc);
         if ($od1 ne undef) {
            $outAsm .= sprintf("%-4s %s",$mne,$od1);
            $outAsm .= ", $od2" if ($od2 ne undef);
         } else {
            $outAsm .= $mne;
         }
#         _PrintStr $winMain::text->index('insert').": ";
         _PrintNormal "$outAsm\n";
      }
   }

   # remove objdump+refsAddr
   close(FH);
   unlink($tmpName);
   %refsAddr = ();

   # RefsType->Dialogs
#   _RefsOutput('refsType',%refsType);
   _RefsTypeToDialogs();
}

#-----------------
# _RefToFile(*$$$)
#
# in:  filehandle,Type-string,data-reference,data-name
# out: -

sub _RefToFile(*$$$)
{
   local *FH = shift;
   my ($tstr,$dref,$dname) = @_;

   _PrintProgress "- $tstr\n";
   print FH "[$tstr]\n";
   print FH Data::Dumper->Dump([$dref],[$dname]);
}

#--------------------
# ListingToProject($)
#
# Saves the listing in a listing file and the additional informations in a
# project file.
#
# in:  Filename
# out: -

sub ListingToProject($)
{
   my $fname = shift;

   _PrintProgress "\n*** Listing To Project ***\n\n";
   # Filenames
   my $listName = $fname.$main::cfg->Get('ListingExt');
   my $prjName  = $fname.$main::cfg->Get('ProjectExt');

   # Save listing
   _PrintProgress "Save listing...\n";
   open(LF,"> $listName");
   for (my $curRow=1; $curRow <= $winFunc::numRows; $curRow++) { # a single get crashs my pc
      print LF $winMain::text->get("$curRow.0","$curRow.end")."\n";
   }
   close(LF);

   # Save project-file
   _PrintProgress "Save project...\n";
   open(PF,"> $prjName");
   _RefToFile(*PF,'Sections',\%sections,'sections');
   _RefToFile(*PF,'References',\%refsType,'refsType');
   for ('function','string','internal') {
      _RefToFile(*PF,"Tag:$_",[$winMain::text->tagRanges($_)],'tagTemp');
   }
   print PF "[EOF]\n";
   close(PF);
}

#--------------------
# ProjectToListing($)
#
# Opens a project and the listing
#
# in: Project-filename

sub ProjectToListing($)
{
   my $prjName = shift;

   _PrintProgress "\n*** Project To Listing ***\n\n";
   # Open listing
   _PrintProgress "Open listing...\n";
   my $pext = $main::cfg->Get('ProjectExt');
   my $lext = $main::cfg->Get('ListingExt');
   (my $listName = $prjName) =~ s/$pext/$lext/;
   open(LF,"< $listName");
   while (<LF>) {
      _PrintNormal($_);
   }
   close(LF);

   # Open project
   open(LF,"< $prjName");

   my ($buffer,$secName,$tagTemp,$sections,$refsType);
   while (my $line = <LF>) {
      # New data?
      if ($line =~ /^\[([^\]]+)\]/) {
         if ($secName ne undef) {
            my ($desc,$spec) = split(/:/,$secName);
            if (($desc eq 'Sections') || ($desc eq 'References')) {
               eval($buffer);
            } elsif ($desc eq 'Tag') {
               eval($buffer);
					$winMain::text->tagAdd($spec,@{$tagTemp})
						if (@{$tagTemp} > 0);
            }
            $buffer = undef;
         }
         $secName = $1;
      # Just append to buffer
      } else {
         $buffer .= $line;
      }
   }
   close(LF);

   # Type to dialogs
   %sections = %{$sections};
   %refsType = %{$refsType};
   _RefsTypeToDialogs();
}

#--------------
# IsCodeAddr($)
#
# Checks if a given address is in one of the code-sections
#
# in:  Address
# out: 0=no, >0=yes,section is starting at row

sub IsCodeAddr($)
{
   my $uaddr = hex shift;

   foreach (keys %sections) {
      if ($sections{$_}->{'type'} eq 'code') {
         return $sections{$_}->{'row'} if (($uaddr >= $sections{$_}->{'vma'}) &&
                                           ($uaddr <= $sections{$_}->{'vma_end'}));
      }
   }

   return 0;
}

#-----------------
# GetSectionRow($)
#
# Returns the row of a specific section
#
# in:  Section-name
# out: Row or undef if section n.a.

sub GetSectionRow($)
{
#   print "GSR : $_[0]\n";
#   foreach my $vk(keys %sections) {
#      print "$vk:\n";
#      foreach (keys %{$sections{$vk}}) {
#         print "  - $_ = '$sections{$vk}->{$_}'\n";
#      }
#   }

   return ($sections{$_[0]} ne undef) ? $sections{$_[0]}->{'row'} : undef;
}


1;
