package winFunc;

#
# winFunc.pm
#
# [ldasm] Callback-functions for all windows
#

use strict;
use Tk;
use Tk::Text;
use Tk::DialogBox;
use File::Basename;

use winMain;
use winDlg;
use asmps;
use misc;

#-------
# Export

use Exporter;
use vars qw(@ISA @EXPORT $numRows);
@ISA = qw(Exporter);
@EXPORT = qw(&FuncImport &FuncExport &FuncInternal &StringRefs
             &HelpMe &About
             &HelpGotoAnchor
             &MoveRowSelection &RowDblClick
             &OpenFile &SaveFile &SavePrj &OpenPrj
             &SearchResultGoto &SearchText &SearchResultWin &SearchNext
             &AddrToRow &GotoCodeLoc &GotoCodePoint
             &JumpToReference &ReferenceCopy &CopySelCode
             &ExecuteRefOp &ExecuteRefRet
             &Prefs &ExportFileSelect &HTMLExport
				 &ApplyTrace);

#-----------------
# Global variables

   $numRows = 0;
my ($execFilename,$prjFilename);
my $curSelTag = '';
my %refDest = undef;
my %refDlgEntry;
my $oldCursor;

#--------------------------------------------
# FuncImport(), FuncExport(), FuncInternal(),
# StringRefs(), HelpMe(), About(), Prefs()
#
# Shows misc. dialogs

sub FuncImport()   { $FuncImport{top}->deiconify();   }
sub FuncExport()   { $FuncExport{top}->deiconify();   }
sub FuncInternal() { $FuncInternal{top}->deiconify(); }
sub StringRefs()   { $StringRefs{top}->deiconify();   }
sub HelpMe()       { $HelpMe{top}->deiconify();       }
sub About()        { $About{dlg}->Show();             }

#-----------
# HelpJump()
#
# Called when a link is pressed in the help

sub HelpGotoAnchor()
{
   (my $cursorIdx = $HelpMe{txt}->index('current')) =~ s/\..+/\.0/;
   my $anch = $HelpMe{anchor}->{$cursorIdx};
   if ($anch eq undef) {
      print $main::langStr{'ERROR'},': ',
            $main::langStr{'ERR_ANCHOR'}," '$cursorIdx'\n";
   } else {
      my $link = $HelpMe{link}->{$anch};
      if ($link eq undef) {
         print $main::langStr{'ERROR'},': ',
               $main::langStr{'ERR_LINK'}," '$cursorIdx'\n";
      } else {
         $HelpMe{txt}->see($link);
      }
   }
}

#--------------------
# MoveRowSelection($)
#
# in:  special ('+1'|'-1'|'-p'|'+p') or row
# out: -

sub MoveRowSelection($)
{
   my $drow = shift;

   #print "MoveRow:\n";
   #print "NumRows:$numRows, drow:$drow\n";

   # Any row or current
   return if ($numRows == 0);

   # Check if special
   if ($drow eq '+1') {
      $drow = $winMain::currentRow+1;
   } elsif ($drow eq '-1') {
      $drow = $winMain::currentRow-1;
   } elsif ($drow eq '+p') {
      $drow = $winMain::currentRow+$main::cfg->Get('RowsPerPage');
   } elsif ($drow eq '-p') {
      $drow = $winMain::currentRow-$main::cfg->Get('RowsPerPage');

   # No special
   } else {
      $drow =~ s/\..+//; # remove column
   }

   # Valid row?
   if ($drow > $numRows) {
      $drow = $numRows;
   } elsif ($drow <= 0) {
      $drow = 1;
   }

   # Remove old selection
   $winMain::text->tagRemove($curSelTag,
         "$winMain::currentRow.0",($winMain::currentRow+1).".0")
      if ($curSelTag ne undef);

   # Reference ?
   my @lcnt = split(/\s+/,$winMain::text->get("$drow.1","$drow.end"));
   $refDest{'to'} = $asmps::refsType{'ref'}->{$lcnt[0]};
   if ($refDest{'to'} ne undef) {
      $curSelTag = 'overRef';
      $refDest{'type'} = ($lcnt[2] eq 'call') ? 'call' : 'jump';
   } else {
      $curSelTag = 'overNormal';
   }

   # Mark new row
   $winMain::text->tagAdd($curSelTag,"$drow.0",($drow+1).".0");
   $winMain::currentRow = $drow;
   $winMain::text->see("$drow.0");
}

#--------------
# RowDblClick()
#
# A double-click sets a new row
#
# in+out: -

sub RowDblClick()
{
   MoveRowSelection($winMain::text->index('current'));
}

#------------------
# _CleanUpWidgets()
#
# Removes the content from all widgets (text, etc.), enables writting and
# shows the progress window.
#
# in+out: -

sub _CleanUpWidgets()
{
   # Save file?
   if ($execFilename ne undef) {
      SavePrj() if (MsgBox($main::langStr{'SAVECURRENT'}.' ?'));
   }

   # References
   for (\%FuncImport,\%FuncExport,\%FuncInternal,\%StringRefs) {
      $_->{top}->withdraw();
      $_->{listbox}->delete(0,'end');
   }

   # Asm-window
   $winMain::text->configure(-state => 'normal');
   $winMain::text->delete('1.0','end');

   # Progress-window
   $Progress{text}->delete('1.0','end');
   $Progress{top}->deiconify();
}

#---------------------
# _ProgressFinished($)
#
# Hides the progress window,disabled write-access to the asm-window and
# sets the cursor on the first row.
#
# in:  filename
# out: filename w/o path

sub _ProgressFinished($)
{
   my $fname = shift;

   # Update main-window-title
   $fname =~ s|.+/([^/]+)$|$1|;
   $winMain::win->title($main::cfg->Get('WinTitle')." [$fname]");
   $winMain::win->iconname($main::cfg->Get('IconName').$fname);

   # Widgets
   $winMain::text->configure(-state => 'disabled');
   $Progress{top}->withdraw();

   # Misc vars
   %refDlgEntry = undef;
   %refDest = undef;
   $curSelTag = '';
   ($numRows = $winMain::text->index('end')) =~ s/\..+//;
   $numRows--;

   # Selection to first row
   MoveRowSelection(1);

   return $fname;
}

#-----------
# OpenFile()
#
# Creates and shows the main-window

sub OpenFile()
{
   # Show dialog and abort if no file choosen
	my $efname = FileSelDlg(
		-title =>  $main::langStr{'SELDIS'}
	);
   return if ($efname eq undef);

   # Create listing
   _CleanUpWidgets();
   CreateListing($efname);
   $execFilename = _ProgressFinished($efname);
}

#--------------
# SaveFile($;$)
#
# Dialog to save a file - used by "SavePrj" and "HTMLExport"
#
# in: Init-filename

sub SaveFile($;$)
{
   my ($initf) = @_;

	my $fname = FileSelDlg(
		-title       => $main::langStr{'SAVEAS'},
		-initialfile => $initf
	);
   if (($fname eq '') || ($fname =~ /\*$/)) {
      ErrBox($main::langStr{'NOFILE'});
      return;
   }
   return $fname;
}

#----------
# SavePrj()
#
# Saves a disassembled file

sub SavePrj()
{
   # A file available?
   return if ($execFilename eq undef);

   # Save
   my $fname = SaveFile($execFilename);
   return if ($fname eq undef);
   ListingToProject($fname);
}

#----------
# OpenPrj()
#
# OpenProject

sub OpenPrj()
{
   # Open-dialog
	my $fname = FileSelDlg(
		-title  => $main::langStr{'SELPRJ'},
		-filter => '*'.$main::cfg->Get('ProjectExt')
	);
   return if ($fname eq undef);

   # Read file
   _CleanUpWidgets();
   ProjectToListing($fname);
   _ProgressFinished($fname);
   $execFilename = undef;
   $prjFilename = $fname;
}

#-------------------
# SearchResultGoto()
#
# Double-click on a search-result row

sub SearchResultGoto()
{
   my $srow = $SearchResult{listbox}->get('active');
   MoveRowSelection($srow);
}

#-------------
# SearchText()
#
# Searchs for a user-specified string

sub SearchText()
{
   # Dialog
   return if (($SearchText{dlg}->Show() eq $SearchText{btn}->[0]) ||
              ($SearchText{txt} eq ''));

   # Initialisation
   $SearchResult{top}->withdraw();
   $SearchResult{listbox}->delete(0,'end');
   my @sargs;
   push(@sargs,'-nocase') if (!$SearchText{case});
   push(@sargs,'-regexp') if ($SearchText{regexp});
   push(@sargs,'-forward');

   # Search
   my $curRow = 1;
   my $lastRow = 0;
   $SearchResult{matches} = 0;

   while (my $sIndex = $winMain::text->search(@sargs,$SearchText{txt},"$lastRow.0")) {
      ($curRow = $sIndex) =~ s/\..+//;
      last if ($curRow < $lastRow);
      $SearchResult{listbox}->insert('end',$curRow);
      $SearchResult{matches}++;
      $lastRow = $curRow+1;
   }

   # Handle results (incl. window)
   if ($SearchResult{matches} != 0) {
      # Active entry
      if ($SearchText{reswin} || ($SearchText{dir} eq 'down')) {
         $SearchResult{listbox}->activate(0);
      } else {
         $SearchResult{listbox}->activate('end');
      }
      # Unhide result-window or select row
      if ($SearchText{reswin}) {
         $SearchResult{top}->deiconify();
      } else {
         SearchResultGoto();
      }

   # Nothing found
   } else {
      ErrBox($main::langStr{'NOFOUND'});
   }
}

#------------------
# SearchResultWin()
#
# Shows the result-window

sub SearchResultWin()
{
   $SearchResult{top}->deiconify() if ($SearchText{reswin});
}

#-------------
# SearchNext()
#
# Jumps to the next search result-entry

sub SearchNext()
{
   # Nothing found - abort
   return if ($SearchResult{matches} == 0);

   # Get current item-no. and deselect it
   (my $actItem = $SearchResult{listbox}->index('active')) =~ s/\..+//;
   $SearchResult{listbox}->selection('clear','active');

   # dir: down
   if ($SearchText{dir} eq 'down') {
      $actItem++;
      $actItem = 0 if ($actItem == $SearchResult{matches});

   # dir: up
   } else {
      if ($actItem == 0) {
         $actItem = 'end';
      } else {
         $actItem--;
      }
   }

   # Activate and jump to it
   $SearchResult{listbox}->activate($actItem);
   $SearchResult{listbox}->selection('set','active');
   $SearchResult{listbox}->see('active');

   SearchResultGoto();
}

#---------------
# AddrToRow($;$)
#
# "Converts" a addr in a text-row
#
# in:  Addr [,defined = seek back if ref]
# out: Index (undef = failure)

sub AddrToRow($;$)
{
   my ($addr,$seekBack) = @_;

   # Is valid address ?
   my $srow = IsCodeAddr($addr);
   if ($srow == 0) {
      ErrBox("$addr ".$main::langStr{'INADDR'});
      return;
   }

   # Search address
   my $listAddr = '^:'.(($addr !~ /^0/) ? '0' : '').$addr;
   my $addrIndex = $winMain::text->search(
      '-forward',
      '-nocase',
      '-regexp',
      $listAddr,
      $srow
   );
   if ($addrIndex eq undef) {
      ErrBox("$GotoCodeLoc{ofs} ".$main::langStr{'INTPOL'});
      return;
   }
   $addrIndex =~ s/\..+//;

   # Ref: Seek-back
   if ($seekBack ne undef) {
      while ($winMain::text->get("$addrIndex.0-1 lines") ne ':') {
         $addrIndex--;
      }
   }

   return $addrIndex;
}

#--------------
# GotoCodeLoc()
#
# Dialog to enter a offset and jumps (if possible) to it

sub GotoCodeLoc()
{
   return if ($GotoCodeLoc{dlg}->Show() eq $GotoCodeLoc{btn}->[0]);

   my $addrRow = AddrToRow($GotoCodeLoc{ofs});
   MoveRowSelection($addrRow) if ($addrRow ne undef);
}

#-----------------
# GotoCodePoint($)
#
# Jumps to the code-start of entry-point

sub GotoCodePoint($)
{
   my $alias = shift;

   # Get row the section starts
   my %SectionAlias = (
      'start' => '.init',
      'ep'    => '.text'
   );
   return if (!exists $SectionAlias{$alias});
   my $secRow = GetSectionRow($SectionAlias{$alias});
   return if ($secRow eq undef);

   # Skip unnecessary rows
   $secRow =~ s/\..+//;
   while ($winMain::text->get("$secRow.0") ne ':') {
      $secRow++;
   }
   MoveRowSelection($secRow);
}

#-------------------
# JumpToReference($)
#
# Jumps to the reference if double-clicked
# Not in Export list, because both winFunc & winDlg link each other
#
# in:  toplevel-reference
# out: -

sub JumpToReference($)
{
   my $reftl = shift;

#   print "Type: $reftl->{type}\n";
   my $rstr = $reftl->{listbox}->get('active');
#   print "Active: '$rstr'\n";
   return if ($rstr eq undef);
   my $symref = $asmps::refsType{$reftl->{type}};
   return if ($symref eq undef);
   $symref = $symref->{$rstr};
   return if ($symref eq undef);

   if (ref $symref eq 'ARRAY') {
      if (exists $refDlgEntry{$symref}) {
         $refDlgEntry{$symref}++;
         $refDlgEntry{$symref} = 0 if ($refDlgEntry{$symref} == @{$symref});
      } else {
         $refDlgEntry{$symref} = 0;
      }
#      print "Array: ".@{$symref}." entries\n";
      # Move selection
#      print "Num: $refDlgEntry{$symref} - $symref->[$refDlgEntry{$symref}]\n";
      MoveRowSelection($symref->[$refDlgEntry{$symref}]);
#      print "> ".@{$symref}." Eintr�ge\n";
   } else {
#      print "NAA: $symref\n";
      MoveRowSelection($symref);
#      print "> 1 Eintrag\n";
   }
}

#--------------
# ReferenceCopy
#
# Copies the selected or all entries

sub ReferenceCopy
{
   my ($mode,$reftl) = @_;

   # Copy all
   if ($mode eq 'all') {
      for ($reftl->{listbox}->get(0,'end')) {
         print "$_\n";
      }

   # Selected
   } else {
      my $rcnt = $reftl->{listbox}->get('active');
      print "$rcnt\n" if ($rcnt ne undef);
   }
}

#--------------
# CopySelCode()
#
# Copies a single code-line

sub CopySelCode()
{
   if ($numRows > 0) {
      my $cline = $winMain::text->get("$winMain::currentRow.0","$winMain::currentRow.end");
      $cline =~ s/\s{2,}/ /g;
      print "$cline\n" if ($cline ne undef);
   }
}

#-------------
# ExecuteRefOp
#
# Executes a call or jump

sub ExecuteRefOp
{
   my $type = shift;

   # Not the required dereferencation-type
   return if (($refDest{'to'} eq undef) || ($refDest{'type'} ne $type));

   # Move selection and update deref-history
   push(@{$refDest{'history'}},{type => $type,row => $winMain::currentRow});
   MoveRowSelection($refDest{'to'});
}

#--------------
# ExecuteRefRet
#
# Returns from a jump or call

sub ExecuteRefRet
{
   my $type = shift;

   return if (($refDest{'history'} eq undef) ||
              (@{$refDest{'history'}} == 0)  ||
              ($refDest{'history'}->[-1]->{'type'} ne $type));

   my $th = pop @{$refDest{'history'}};
   MoveRowSelection($th->{'row'});
}

#--------
# Prefs()
#
# Modification of the preferences

sub Prefs()
{
   # Show dialog
   $Prefs{dlg}->Show();

   # Get language
   my $lg = $Prefs{lang}->{$Prefs{listbox}->get('active')};

   # Save
   $main::cfg->Set('Language',$lg);
   my $cfgfname = $ENV{'HOME'}.'/'.$main::cfg->Get('UserConfig');
   if ($main::cfg->Save($cfgfname) eq undef) {
      ErrBox($main::langStr{'PREFSAVE'}."' - '$cfgfname'");
   }
}

#-------------------
# ExportFileSelect()
#
# Selection of the "(HTML)Export"-filename

sub ExportFileSelect()
{
   my $htmlExt = $main::cfg->Get('HTMLExt');
#   (my $exFname = ($execFilename || $prjFilename)) =~ s/\.[^.]$//;
	my $exFname = basename($execFilename || $prjFilename);
   $exFname .= $htmlExt;

   $exFname = SaveFile($exFname);
   $HTMLExport{fname} = $exFname if ($exFname ne undef);
}

#-------------
# HTMLExport()
#
# Exports a part or the whole listing as HTML-file

sub HTMLExport()
{
    # A file available?
   return if (($execFilename || $prjFilename) eq undef);

   # Show dialog
   my $ret = $HTMLExport{dlg}->Show();
   return if ($ret eq $HTMLExport{btn}->[0]);

   # Filename given ?
   if ($HTMLExport{'fname'} eq '') {
      ErrBox($main::langStr{'NOFILE'});
      return;
   }

   # Range
   my ($fromRow,$toRow);
   if ($HTMLExport{'range'} ne 'complete') {
      return if ((($fromRow = AddrToRow($HTMLExport{'rgFrom'},1)) eq undef) ||
                 (($toRow   = AddrToRow($HTMLExport{'rgTo'})) eq undef));
   } else {
      $fromRow = 1;
      $toRow = $numRows+1;
   }

   # Some req. HTML-constants
   my $HTMLStart = "<html><head><title>LDasm HTML-Export</title>\n"
                  ."<style type=\"text/css\">\n"
                  ."   BODY { font-family:\"Courier New\",Courier,monospace; }\n"
                  ."   .ld_function { color:green; }\n"
                  ."   .ld_internal { color:navy;  }\n"
                  ."   .ld_string   { color:navy;  }\n"
						."   .ld_trace    { color:red;   }\n"
                  ."</style></head>\n"
                  ."<body text=\"Black\">\n"
                  ."<font face=\"Courier New\">\n";
   my $HTMLEnd = "</font>\n</body></html>\n";
   my %FontColor = (
      'function' => 'green',
      'internal' => 'navy',
      'string'   => 'navy',
		'trace'    => 'red'
   );

   # Write the file
   open(HF, ">$HTMLExport{fname}") or do {
      ErrBox($main::langStr{'HTMLFile'}." - $!");
      return;
   };
   print HF $HTMLStart;
   for (my $akt = $fromRow; $akt <= $toRow; $akt++) {
      # Get line
      my $asmline = $winMain::text->get("$akt.0","$akt.end");
      chomp($asmline);
		if ($asmline eq undef) {
			print HF "<br>\n";
		} else {
			$asmline =~ s/\s/&nbsp;/g;
			# Font
			my $tn = $winMain::text->tagNames("$akt.0");
			if ($tn ne 'normal') {
				print HF "   <font color=\"$FontColor{$tn}\" class=\"ld_$tn\">";
				# trace need some special "treatment"
				if ($tn eq 'trace') {
					print HF substr($asmline,0,9),'</font>';
					print HF substr($asmline,9),"<br>\n";
				} else {
					print HF $asmline,"</font><br>\n";
				}
      	} else {
				print HF "   $asmline<br>\n";
			}
		}
   }
   print HF $HTMLEnd;
   close HF;
}

#---------------
# ApplyTrace()
#
# Open and apply a trace-log created with ptrace

sub ApplyTrace()
{
	return if ($numRows == 0);

   # Show dialog and abort if no file choosen
	my $traceFname = FileSelDlg(
		-title =>  $main::langStr{'SELTRACE'},
		-filter => '*'.$main::cfg->Get('TraceExt')
	);
	return if ($traceFname eq undef);

	# Go through the whole trace-log
	open(TF,"<$traceFname");
	my $line = <TF>;
	my $trAddr = (split(/ /,$line))[0];
	my $curRow;
	for ($curRow = 1; $curRow <= $winFunc::numRows; $curRow++) {
		next if ($winMain::text->get("$curRow.0","$curRow.9") !~ /^:(.{8})/);
		if ($trAddr eq $1) {
			$winMain::text->tagAdd('trace',"$curRow.0","$curRow.9");
			last if (!($line = <TF>));
			$trAddr = (split(/ /,$line))[0];
		} else {
			if ($winMain::text->tagNames("$curRow.1") eq 'trace') {
				$winMain::text->tagRemove('trace',"$curRow.0","$curRow.9");
			}
		}
	}
	close TF;

	# Untag rest of listing
	while ($curRow <= $winFunc::numRows) {
		if ($winMain::text->tagNames("$curRow.1") eq 'trace') {
			$winMain::text->tagRemove('trace',"$curRow.0","$curRow.9");
		}
		$curRow++;
	}
}



1;
