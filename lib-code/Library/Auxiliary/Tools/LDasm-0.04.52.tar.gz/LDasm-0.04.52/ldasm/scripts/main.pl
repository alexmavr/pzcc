#!/usr/bin/perl
# ldasm.pl
#
# [ldasm] Startup-code

use strict;

#---------------------
# Accessable variables

use vars qw($cfg %langStr %langAvail);

#-------------
# Private vars

my $LDasmPath;

#---------------
# Initialisation

BEGIN
{
   # Path initialisation
   $LDasmPath = $ENV{LDASM_DIR};
   die "Error: Enviroment variable 'LDASM_DIR' not set - execution aborted!\n\n"
      if ($LDasmPath eq undef);
   unshift(@INC,"$LDasmPath/scripts");
}

#---------
# MainLoop

use Tk;
use config;
use winMain;
use winDlg;

# Base-configuration
$cfg = new config("$LDasmPath/ldasm.cfg",1);
die "Error: $config::error\n" if ($cfg eq undef);
$cfg->Set('RCPath',"$LDasmPath/".$cfg->Get('RCPath'));

# User-specific config
my $ucfg = $cfg->Get('UserConfig');
$cfg->Open($ENV{'HOME'}.'/'.$ucfg);

# Version-check
if (($cfg->Get('VersionStr') ne 'v0.03')
 && ($cfg->Get('VersionStr') ne 'v0.04')) {
	die "ATTENTION: The config has changed!\n"
		."  1. Remove ~/ucfg\n"
		."  2. Restart LDasm\n";
}

# Language
my $lang = new config($cfg->Get('RCPath').'/misc/strings.cfg');
die "Error: $config::error\n" if ($lang eq undef);
%langStr = $lang->GroupGet($cfg->Get('Language'));
%langAvail = $lang->Get();

# Dialogs+Tk
CreateWinMain();
CreateAllDialogs();
MainLoop();

