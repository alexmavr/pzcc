package winMain;

#
# winMain.pm
#
# [ldasm] The main-window
#

use strict;
use Tk;
use Tk::Text;
use Tk::Balloon;

use winFunc;
use misc;
use asmps;

#-------
# Export

use Exporter;
use vars qw(@ISA @EXPORT $win $text $currentRow $currentOfs);
@ISA = qw(Exporter);
@EXPORT = qw(&CreateWinMain);

#-----------------
# Global variables

# Accessable from outside
$currentRow = 1;
$currentOfs = 1;

# Private
my ($currentOfs);
my ($winBalloon,$menuFrame,$buttonFrame);

#------------
# ReadMenu($)
#
# Reads the menu-file
#
# in: menu-filename

sub ReadMenu($)
{
   my $menuName = shift;

   # The available menu-commands (name-subroutine-hash)
   my %MenuCommands = (
      'OPEN'       => \&OpenFile,
      'SAVE'       => \&SavePrj,
      'HTMLEXPORT' => \&HTMLExport,
		'TRACE'      => \&ApplyTrace,
      'COPY'       => \&CopySelCode,
      'PREFS'      => \&Prefs,
      'EXIT'       => sub {exit(0);},
      'OPENPRJ'    => \&OpenPrj,
      'SEARCH'     => \&SearchText,
      'FINDNEXT'   => \&SearchNext,
      'RESULTWIN'  => \&SearchResultWin,
      'GOTOCODE'   => [\&GotoCodePoint,'start'],
      'GOTOENTRY'  => [\&GotoCodePoint,'ep'],
      'GOTOLOC'    => \&GotoCodeLoc,
      'JUMP'       => [\&ExecuteRefOp,'jump'],
      'RETJMP'     => [\&ExecuteRefRet,'jump'],
      'CALL'       => [\&ExecuteRefOp,'call'],
      'RETCALL'    => [\&ExecuteRefRet,'call'],
      'FUNCTIONS'  => \&FuncImport,
      'EXPORTS'    => \&FuncExport,
      'INTERNAL'   => \&FuncInternal,
      'STRINGS'    => \&StringRefs,
      'HELP'       => \&HelpMe,
      'ABOUT'      => \&About
   );

   # Try to open the menufile
   open(FH,"< $menuName") or
      die $main::langStr{'ERROR'}.' '.$main::langStr{'ERR_MENU'}." $menuName!\n";

   # Read the damn thing
   my ($inMenu,$inItem) = (0,0);
   my ($menuBtn,%menuItem,$metaPos,$metaKey);

   while (my $line = <FH>) {
      # Skip if empty line or comment
      chomp($line);
      $line =~ s/\s+(".+?")?/$1/g;
      next if (($line =~ /^;/) || ($line eq ''));

      # Is Menu-string ?
      if ($line =~ s/"//g) {
         # Handle meta-key
         $metaPos = index($line,'&');
         if ($metaPos != -1) {
            $line =~ s/&(.)/$1/;
            $metaKey = 'Meta+'.uc $1;
         } else {
            $metaPos = 0;
            $metaKey = undef;
         }

         # New button or item
         if ($inMenu) {
            $menuItem{'label'} = $line;
            $inItem = 1;
         } else {
            $menuBtn = $menuFrame->Menubutton(
               -text        => $line,
               -underline   => $metaPos
            )->pack(
               -side => 'left',
               -padx => 2
            );
            $inMenu = 1;
         }

         # End ?
      } elsif ($line eq 'end') {
         # Add item
         if ($inItem) {
            # Menu-item
            my $cmd = $MenuCommands{$menuItem{'cmd'}};

            # Key-binding (must be before the "Tk->command!)
            if ($menuItem{'key'} ne undef) {
               my $bkey = $menuItem{'key'};
               $bkey =~ s/\+(.)/'-'.(lc $1)/e;
               $bkey =~ s/Ctrl/Control/;
               $bkey =~ s/<-/Left/;
               $bkey =~ s/->/Right/;

               if (ref $cmd eq 'ARRAY') {
                  $win->bind("<$bkey>" => sub { $cmd->[0]->($cmd->[1]); });
               } else {
                  $win->bind("<$bkey>" => $cmd);
               }
            }

            # Add menu-item
            $menuBtn->command(
               -label       => $menuItem{'label'},
               -command     => $cmd,
               -state       => ($cmd ne undef) ? 'normal' : 'disabled',
               -underline   => $metaPos,
               -accelerator => $menuItem{'key'}
            );

            # Button in toolbar
            if ($menuItem{'icon'} ne undef) {
               my $bt = $buttonFrame->Button(
                  -image   => $buttonFrame->Pixmap(
                     -file => $main::cfg->Get('RCPath')."/icons/$menuItem{'icon'}.xpm"
                  ),
                  -command => $cmd
               )->pack(
                  -side => 'left'
               );
               $winBalloon->attach($bt,
                  -balloonmsg => $menuItem{'label'}
               );
            }
            %menuItem = ();
            $inItem = 0;
         } else {
            $inMenu = 0;
         }

      # Separator ?
      } elsif ($line =~ /^-/) {
         $menuBtn->separator();

      # Item-options
      } else {
         my @tmp = split(/=/,$line);
         $menuItem{$tmp[0]} = $tmp[1];
      }
   }
   close(FH);
}

#--------------------
# CreateWinMain()
#
# Creates the main-window

sub CreateWinMain()
{
   $win = MainWindow->new();
   $win->title($main::cfg->Get('WinTitle'));
   $win->iconname($main::cfg->Get('IconName'));

   # Ballon for the main-window (tooltips in Windows)
   $winBalloon = $win->Balloon(
      -initwait => 400,
      -state    => 'balloon'
   );

   # Bindings
   $win->bind('<Up>'    => sub { MoveRowSelection('-1'); });
   $win->bind('<Down>'  => sub { MoveRowSelection('+1'); });
   $win->bind('<Prior>' => sub { MoveRowSelection('-p'); });
   $win->bind('<Next>'  => sub { MoveRowSelection('+p'); });

   # Menu (menu+toolbar)
   $menuFrame = $win->Frame()->pack(
      -side => 'top',
      -fill => 'x'
   );
   $buttonFrame = $win->Frame()->pack(
      -side => 'top',
      -fill => 'x'
   );
   ReadMenu($main::cfg->Get('RCPath').'/misc/menu.'.$main::cfg->Get('Language'));

   # Statebar
   my $stateFrame = $win->Frame()->pack(
      -side => 'bottom',
      -fill => 'x'
   );

   # Statebar:Address
   $stateFrame->Label(
      -text => $main::langStr{'ROW'}.':'

   )->pack(
      -side => 'left'
   );
   $stateFrame->Label(
      -anchor       => 'w',
      -textvariable => \$currentRow,
      -relief       => 'sunken',
      -width        => '8'
   )->pack(
      -side => 'left'
   );

   # Statebar:Offset
   $stateFrame->Label(
      -text => 'Ofs:'
   )->pack(
      -side => 'left'
   );
   $stateFrame->Label(
      -anchor       => 'w',
      -textvariable => \$currentOfs,
      -relief       => 'sunken',
      -width        => '10'
   )->pack(
      -side => 'left'
   );

   # Widget for assembler-source+set tags+key bindings
   $text = $win->ScrlText(
      -state            => 'disabled',
      -scrollbars       => 'se',
      -wrap             => 'none',
      -takefocus        => 0,
      -bg               => 'gray',
      -selectforeground => 'black',
      -selectbackground => 'gray',
      -selectborderwidth => 0

   )->pack(
      -expand => 1,
      -fill   => 'both'
   );
   TextTags($text,'FontAsm');
   $text->bind('<Double-1>' => \&RowDblClick);
}


1;
