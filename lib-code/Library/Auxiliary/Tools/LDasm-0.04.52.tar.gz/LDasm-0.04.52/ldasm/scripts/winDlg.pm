package winDlg;

# winDlg.pm
#
# [ldasm] Creates all required dialogs
#

use strict;

use winMain;
use winFunc;
use misc;

#-------
# Export

use Exporter;
use vars qw(@ISA @EXPORT
            %SearchText %SearchResult
            %GotoCodeLoc
            %FuncImport %FuncExport %FuncInternal %StringRefs
            %HelpMe %About
            %Progress
            %Prefs
            %HTMLExport);
@ISA = qw(Exporter);
@EXPORT = qw(&CreateAllDialogs
            %SearchText %SearchResult
            %GotoCodeLoc
            %FuncImport %FuncExport %FuncInternal %StringRefs
            %HelpMe %About
            %Progress
            %Prefs
            %HTMLExport);

#-----------------
# Dialog-variables

my %RefsButtons;

sub _InitDlgVars()
{
   %SearchText = (
      btn  => [
         $main::langStr{'CANCEL'},$main::langStr{'SEARCH'}],
      txt    => '',
      case   => 0,
      regexp => 0,
      dir    => 'down',
      reswin => 0
   );
   %SearchResult = (
      btn => {
         $main::langStr{'GOTO'} => sub { winFunc::SearchResultGoto(); }
      },
      matches => 0
   );
   %GotoCodeLoc = (
      btn  => [
         $main::langStr{'CANCEL'},'OK'],
      ofs  => 0
   );
   %RefsButtons = (
      $main::langStr{'COPYALL'}  => [\&winFunc::ReferenceCopy,'all'],
      $main::langStr{'COPYVIEW'} => [\&winFunc::ReferenceCopy,'view']
   );
   %HTMLExport = (
      btn   => [
         $main::langStr{'CANCEL'},'OK'],
      fname   => '',
      range   => 'complete',
      rgFrom  => 0,
      rgTo    => 0,
      noLinks => 0
   );
}

#-------------
# _DlgSearch()
#
# Dialog for "search-Text"

sub _DlgSearch()
{
   $SearchText{dlg} = $winMain::win->DialogBox(
      -title   => $main::langStr{'SEARCH'},
      -buttons => [@{$SearchText{btn}}],
      -default_button => $SearchText{btn}->[1]
   );
   my $sinput = $SearchText{dlg}->add('Frame')->pack(
      -side => 'top'
   );
   my $sopts1 = $SearchText{dlg}->add('Frame')->pack(
      -side => 'left'
   );
   my $sopts2 = $SearchText{dlg}->add('Frame')->pack(
      -side   => 'right'
   );
   $sinput->Label(
      -text => $main::langStr{'SEARCHFOR'}
   )->pack(
      -side => 'left',
      -padx => 6
   );
   $sinput->Entry(
      -textvariable => \$SearchText{txt},
      -width        => 30,
      -bg           => 'white'
   )->pack(
      -side => 'right'
   );
   $sopts1->Checkbutton(
      -text     => $main::langStr{'CASE'},
      -variable => \$SearchText{case}
   )->pack(
      -side   => 'top',
      -anchor => 'w'
   );
   $sopts1->Checkbutton(
      -text     => $main::langStr{'REGEXP'},
      -variable => \$SearchText{regexp}
   )->pack(
      -side   => 'top',
      -anchor => 'w'
   );
   $sopts1->Checkbutton(
      -text     => $main::langStr{'USERESWIN'},
      -variable => \$SearchText{reswin}
   )->pack(
      -side   => 'top',
      -anchor => 'w'
   );
   my $sdl = $sopts2->Label(
      -relief => 'groove',
   )->pack(
      -side => 'left'
   );
   $sdl->Label(
      -text => $main::langStr{'SEARCHDIR'}
   )->pack(
      -side => 'top'
   );
   $sdl->Radiobutton(
      -text     => $main::langStr{'UP'},
      -variable => \$SearchText{dir},
      -value    => 'up'
   )->pack(
      -side => 'left'
      );
   $sdl->Radiobutton(
      -text     => $main::langStr{'DOWN'},
      -variable => \$SearchText{dir},
      -value    => 'down'
   )->pack(
      -side => 'left'
   );
}

#-------------------
# _DlgSearchResult()
#
# Dialog for "SearchResult

sub _DlgSearchResult()
{
   $SearchResult{top} = ClientWin(
      -title   => $main::langStr{'RESULT'},
      -buttons => $SearchResult{btn}
   );
   my $flframe = $SearchResult{top}->Frame()->pack(
      -side   => 'top',
      -anchor => 'w'
   );
   $flframe->Label(
      -textvariable => \$SearchResult{matches}
   )->pack();
   $SearchResult{listbox} = $flframe->ScrlListbox(
      -width      => 10,
      -height     => 15,
      -background => 'white'
   )->pack();

   # Mouse-binding
   $SearchResult{listbox}->bind('<Double-1>',\&winFunc::SearchResultGoto);
}

#------------------
# _DlgGotoCodeLog()
#
# Dialog for "GotoCodeLoc"

sub _DlgGotoCodeLog()
{
   $GotoCodeLoc{dlg} = $winMain::win->DialogBox(
      -title   => $main::langStr{'SELOFS'},
      -buttons => [@{$GotoCodeLoc{btn}}],
      -default_button => $GotoCodeLoc{btn}->[1]
   );
   $GotoCodeLoc{dlg}->add('Label',
      -text => $main::langStr{'GOTOLOC'}.':'
   )->pack(
      -side => 'left',
      -padx => 6
   );
   $GotoCodeLoc{dlg}->add('Entry',
      -textvariable => \$GotoCodeLoc{ofs},
      -width        => 20,
      -bg           => 'white'
   )->pack(
      -side => 'left'
   );
}

#---------------------
# _DlgReference(\%$$$)
#
# Creates the toplevel for references
#
# in:  Hashref for toplevel, title, desc, ref-type
# out: -

sub _DlgReference(\%$$$)
{
   my ($hrt,$title,$dsc,$rtype) = @_;

   # Assign button-hash to ref-hash
   foreach (keys %RefsButtons) {
      $hrt->{btn}->{$_} = [@{$RefsButtons{$_}},$hrt];
   }

   # Dialog
   $hrt->{top} = ClientWin(
      -title   => $main::langStr{'ALIST'}." $title",
      -buttons => $hrt->{btn}
   );
   my $flframe = $hrt->{top}->Frame()->pack(
      -side   => 'top',
      -anchor => 'w'
   );
   $flframe->Label(
      -text => $main::langStr{'TOSEARCH'}." $dsc, ".$main::langStr{'DBLCLICK'}
   )->pack();
   $hrt->{listbox} = $flframe->ScrlListbox(
      -width      =>  65,
      -height     => 15,
      -background => 'white'
   )->pack();
   $hrt->{type} = $rtype;

   # Mouse-binding
   $hrt->{listbox}->bind('<Double-1>' => sub { winFunc::JumpToReference($hrt); });
}

#-------------
# _DlgHelpMe()
#
# Help-Dialog - haha beginner

sub _DlgHelpMe()
{
   $HelpMe{top} = ClientWin(
      -title => 'Help (rtfm)'
   );
   print $HelpMe{top}->geometry('620x300');
   $HelpMe{top}->minsize(620,300);
   $HelpMe{top}->resizable('n','y');

   $HelpMe{txt} = $HelpMe{top}->ScrlText(
      -scrollbars => 'e',
      -wrap       => 'none',
      -background => 'white'
   )->pack(
      -expand => 1,
      -fill   => 'both'
   );

   # Insert help-file into text
   TextTags($HelpMe{txt},'FontHelp');
   my $fileFound = 1;
   my $hlpfname = $main::cfg->Get('RCPath').'/misc/help.txt';
   open(HLPFILE,"< $hlpfname") or
      $fileFound = 0;

   if ($fileFound) {
      while (my $line = <HLPFILE>) {
         # Comment ?
         next if ($line =~ /^;/);
         # Is type-desc
         if ($line =~ s/^\[([^\]]+)\]//) {
            my ($type,$spec) = split(/:/,$1);
            # Title
            if ($type eq 't') {
               $HelpMe{txt}->insert('insert',"\n$line\n\n",'title');
            # Section
            } elsif ($type eq 's') {
               $HelpMe{txt}->insert('insert',$line,'section');
            # Link
            } elsif ($type eq 'l') {
               $HelpMe{link}->{$spec} = $HelpMe{txt}->index('insert');
            # Anchor
            } elsif ($type eq 'a') {
               $HelpMe{anchor}->{$HelpMe{txt}->index('insert')} = $spec;
               $HelpMe{txt}->insert('insert',$line,'link');
            # Image
            } elsif ($type eq 'i') {
               $HelpMe{txt}->insert('insert',' 'x($HelpMe{txt}->tagCget('text','lmargin1') >>  3));
               my $img = $HelpMe{txt}->Pixmap(
                  -file => $main::cfg->Get('RCPath')."/$spec.xpm"
               );
               $HelpMe{txt}->imageCreate('insert',
                  -image => $img,
                  -align => 'baseline',
                  -padx  => 6,
                  -pady  => 0
               );
            # New paragraph
            } elsif ($type eq 'p') {
               $HelpMe{txt}->insert('insert',"\n");
            }
         # Normal text
         } else {
            $HelpMe{txt}->insert('insert',$line,'text');
         }
      }
      close(HLPFILE);
   } else {
      ErrBox("Unable to open the helpfile\n$hlpfname");
   }
   $HelpMe{txt}->configure(-state => 'disabled'); # readonly
   $HelpMe{txt}->tagBind('link','<Button-1>',\&winFunc::HelpGotoAnchor);
}

#------------
# _DlgAbout()
#
# "About"-Dialog

sub _DlgAbout()
{
   $About{dlg} = $winMain::win->DialogBox(
      -title => 'About',
   );

   my $label = $About{dlg}->add('Label')->pack(
      -side => 'top');
   my $image = $label->Pixmap(
      -file => $main::cfg->Get('RCPath').'/pics/logo.xpm');
   $label->configure(-image => $image);

   $About{dlg}->add('Label',
      -anchor => 'n',
      -relief => 'groove',
      -text   => 'Version '.$main::cfg->Get('VersionStr')
                 .'.'.$main::cfg->Get('BuildStr')."\n"
                 ."Ravemax/Dextrose (ravemax\@dextrose.com)"
   )->pack(
      -side => 'bottom',
      -fill => 'x'
   );
}

#--------------
# _DlgProgress()
#
# Toplevel to display the progress

sub _DlgProgress()
{
   $Progress{top} = ClientWin(
      -title   => 'Progress...',
      -buttons => undef,
   );
   $Progress{text} = $Progress{top}->ScrlText(
      -width      => 50,
      -height     => 12,
      -scrollbars => 'e',
      -bg         => 'gray'
   )->pack(
      -expand  => 1,
      -fill    => 'both'
   );
   TextTags($Progress{text},'FontProgress');

}

#------------
# _DlgPrefs()
#
# Dialog to select the language (and later maybe more)

sub _DlgPrefs()
{
   # Build dialog
   $Prefs{dlg} = $winMain::win->DialogBox(
      -title   => $main::langStr{'LANGUAGE'},
   );
   $Prefs{listbox} = $Prefs{dlg}->ScrlListbox(
      -width      => 20,
      -height     => 5,
      -background => 'white'
   )->pack();

   # Fill listbox with the available languages
   foreach (keys %main::langAvail) {
      $Prefs{listbox}->insert('end',$main::langAvail{$_});
      $Prefs{lang}->{$main::langAvail{$_}} = $_;
   }
   close(LF);
}

#-----------------
# _DlgHTMLExport()
#
# Dialog to select the export-options

sub _DlgHTMLExport()
{
   # Dialog
   $HTMLExport{dlg} = $winMain::win->DialogBox(
      -title          => $main::langStr{'HTMLEXPORT'},
      -buttons        => $HTMLExport{btn},
      -default_button => $GotoCodeLoc{btn}->[1]
   );

   # File selection
   my $ffr = $HTMLExport{dlg}->Frame()->pack(
      -side => 'top',
      -fill => 'x'
   );
   my $flbl = $ffr->Label(
      -relief => 'groove'
   )->pack(
      -fill => 'both',
   );
   $flbl->Label(
      -text => $main::langStr{'OUTPUT'}.':'
   )->pack(
      -side => 'top',
   );
   $HTMLExport{entry} = $flbl->Entry(
      -textvariable => \$HTMLExport{fname},
      -state        => 'disabled',
      -bg           => 'white',
      -width        => 40
   )->pack(
      -side => 'left'
   );
   $flbl->Button(
      -text    => '..',
      -command => \&winFunc::ExportFileSelect
   )->pack(
      -side => 'right'
   );

   # Range
   my $rfr = $HTMLExport{dlg}->Frame()->pack(
      -side => 'top',
      -fill => 'both'
   );
   my $rlbl = $rfr->Label(
      -relief => 'groove'
   )->pack(
      -fill => 'both'
   );
   $rlbl->Label(
      -text => $main::langStr{'RANGE'}.':'
   )->pack(
      -side => 'top'
   );
   my $compFr = $rlbl->Frame()->pack(
      -side => 'top',
      -fill => 'x'
   );
   my $rangFr = $rlbl->Frame()->pack(
      -side => 'bottom',
      -fill => 'x'
   );
   $compFr->Radiobutton(
      -variable => \$HTMLExport{range},
      -text     => $main::langStr{'COMPLETE'},
      -value    => 'complete'
   )->pack(
      -side => 'left'
   );
   $rangFr->Radiobutton(
      -variable => \$HTMLExport{range},
      -text     => $main::langStr{'FROM'},
      -value    => 'range'
   )->pack(
      -side => 'left'
   );
   $rangFr->Entry(
      -textvariable => \$HTMLExport{rgFrom},
      -bg           => 'white',
      -width        => 10
   )->pack(
      -side => 'left'
   );
   $rangFr->Label(
      -text => $main::langStr{'TO'}
   )->pack(
      -side => 'left'
   );
   $rangFr->Entry(
      -textvariable => \$HTMLExport{rgTo},
      -bg           => 'white',
      -width        => 10
   )->pack(
      -side => 'left'
   );

   # Options
   my $ofr = $HTMLExport{dlg}->Frame()->pack(
      -side => 'bottom',
      -fill => 'x'
   );
   my $olbl = $ofr->Label(
      -relief => 'groove'
   )->pack(
      -fill => 'both'
   );
   $olbl->Label(
      -text => $main::langStr{'OPTIONS'}.':'
   )->pack(
      -side => 'top'
   );
   $olbl->Checkbutton(
      -variable => \$HTMLExport{noLinks},
      -text     => $main::langStr{'LINKS'},
      -state    => 'disabled'
   )->pack(
      -side => 'left'
   );
}

#-------------------
# CreateAllDialogs()
#
# Creates all dialogs

sub CreateAllDialogs
{
   _InitDlgVars();

   _DlgSearch();
   _DlgSearchResult();
   _DlgGotoCodeLog();
   _DlgHelpMe();
   _DlgAbout();
   _DlgProgress();
   _DlgPrefs();
   _DlgHTMLExport();

   _DlgReference(%FuncImport,
      $main::langStr{'IMPORTED'}.' '.$main::langStr{'FUNCTIONS'},
      $main::langStr{'FUNCTION'},'import');
   _DlgReference(%FuncExport,
      $main::langStr{'EXPORTED'}.' '.$main::langStr{'FUNCTIONS'},
      $main::langStr{'FUNCTION'},'export');
   _DlgReference(%FuncInternal,
      $main::langStr{'INTERNAL'}.' '.$main::langStr{'FUNCTIONS'},
      $main::langStr{'FUNCTION'},'internal');
   _DlgReference(%StringRefs,
      $main::langStr{'STRING'},
      $main::langStr{'STRING'},'str');
}


1;
