package config;

# config.pm
#
# Configuration-management modul
#
# Version: 0.01
# (c) Ravemax/Dextrose <ravemax@dextrose.com>
#
# Revision:
#    0.01 - First version
#

require 5.000;

use strict;
use vars qw($VERSION $error);

#-------------------------------
# Global constants and variables

$VERSION = '0.01';
$error = '';

#--------------------
# Function-prototypes

sub _ReadConfig($$);
sub Open($$);
sub new($$;$);
sub _WriteConfig($$$);
sub Save($;$);
sub _Group($$);
sub Get($;$;$);
sub Set($$$;$);
sub Groups($;$);
sub GroupGet($$;$);

#----------------
# _ReadConfig($$)
#
# Used to read the variables and groups
#
# in:  Filehandle,dest
# out: -

sub _ReadConfig($$)
{
   my ($fh,$dref) = @_;

   while (my $line = <$fh>) {
      chomp($line);
      $line =~ s/^\s*((\w+)\s*(=)\s*)?/$2$3/;

      # Skip comments and empty lines
      next if (($line eq '') || ($line =~ /^;/));

      # One level down
      return if ($line eq ')');

      # Level up
      my @tmp = split(/=/,$line);
      if ($tmp[1] eq '(') {
         _ReadConfig($fh,\%{$dref->{$tmp[0]}});

      # Add variable
      } else {
         $dref->{$tmp[0]} = $tmp[1];
      }
   }
}

#---------
# Open($$)
#
# Reads a configuration (use in combination with new to merge a public and a
# private config).
#
# in:  Config-filename
# out: undef = failure

sub Open($$)
{
   my ($self,$fname) = @_;

   open(TFH,"< $fname") or do {
      $error = "Failed to open '$fname' ($!)";
      return;
   };
   $self->{'filename'} = $fname;
   _ReadConfig(*TFH,$self->{'vars'});
   close(TFH);

   return 1;
}

#----------
# new($$;$)
#
# Constructor - initialisation and reads the configuration
#
# in:  Config-filename [,1=dont save even when modified]
# out: Object (undef = failure)

sub new($$;$)
{
   my ($class,$fname,$dontSave) = @_;

   # Create object
   my $self = {
      'vars'     => {},
      'modified' => 0,
      'dontSave' => $dontSave
   };
   bless($self,$class);

   # Read config
   return if ($self->Open($fname) eq undef);

   # Return obj
   return $self;
}

#------------------
# _WriteConfig($$$)
#
# in:  Filehandle,data,level
# out: -

sub _WriteConfig($$$)
{
   my ($fh,$data,$level) = @_;

   # Longest key
   my $maxlen = 0;
   map { $maxlen = length $_ if ($maxlen < length $_); } keys %{$data};

   # Write all keys (case-insensitiv sorted)
   my $lspc = ' 'x($level*3);
   foreach my $vk(sort {lc $a cmp lc $b} keys %{$data}) {
      print $fh $lspc,"$vk ",(' 'x($maxlen-length $vk)),' = ';
      if (ref $data->{$vk}) {
         print $fh "(\n";
         _WriteConfig($fh,$data->{$vk},$level+1);
         print $fh $lspc,")\n";
      } else {
         print $fh "$data->{$vk}\n";
      }
   }
}

#----------
# Save($;$)
#
# Saves the config
#
# in:   [Config-filename]
# out:  undef = failed

sub Save($;$)
{
   my ($self,$fname) = @_;

   # Saving required ?
   if ($self->{'modified'} == 0) {
      $error = 'Nothing modified';
      return;
   }

   # Save
   $fname = $fname || $self->{'filename'};
   open(CF,"> $fname") or do {
      $error = "Failed to write to '$fname' ($!)";
      return;
   };
   _WriteConfig(*CF,$self->{'vars'},0);
   close(CF);

   # Reset flag
   $self->{'modified'} = 0;
   return 1;
}

#--------
# DESTROY
#
# Destructor (default) - calls Save if config was modified
#
# in: Object

sub DESTROY
{
   my $self = shift;

   # Saving if modified
   $self->Save() if ($self->{'modified'} && !$self->{'dontSave'});
}

#-----------
# _Group($$)
#
# Returns a ref to a group if available
#
# in:  destination,group <scalar or anon-array>
# out: reference (undef = failure)

sub _Group($$)
{
   my ($dref,$grp) = @_;

   # Destination reached
   return $dref if ($grp eq undef);

   # Get group-name
   my $gname;
   if (ref $grp eq 'ARRAY') {
      $gname = shift @{$grp};
      $grp = undef if (@$grp == 0);
   } else {
      $gname = $grp;
      $grp = undef;
   }

   # Level up if group exists
   if (!exists $dref->{$gname}) {
      $error = "There is no group called '$gname'";
      return;
   }
   _Group($dref->{$gname},$grp);
}

#-----------
# Get($;$;$)
#
# Returns the value(s) of a specified variable(s)
#
# in:  [variable(s) <scalar or anon-array>  (undef = all)
#      [,group(s) <scalar...>]]
# out: value(s) <scalar,(anon)array or anon-hash> (undef = failure)

sub Get($;$;$)
{
   my ($self,$var,$grp) = @_;

   # Get group-hash-ref
   my $data = _Group($self->{'vars'},$grp);
   return if ($data eq undef);

   # All variables
   if ($var eq undef) {
      my %glvars = ();
      foreach (keys %{$data}) {
         $glvars{$_} = $data->{$_} if (!ref $data->{$_});
      }
      return %glvars;

   # A selected list of variables
   } elsif (ref $var eq 'ARRAY') {
      my @vlist;
      map { push(@vlist,$data->{$_}); } @{$var};
      return @vlist;

   # A single variable
   } else {
      if ($data->{$var} eq undef) {
         $error = "Missing variable '$var'";
         return;
      }
      return $data->{$var};
   }
}

#-----------
# Set($$$;$)
#
# Sets one or more variables
#
# in:  variable(s) <scalar or anon-array>, value(s) <..> [,group(s)]
# out: undef = failure

sub Set($$$;$)
{
   my ($self,$vars,$vals,$grp) = @_;

   # Get group-hash-ref
   my $dest = _Group($self->{'vars'},$grp);
   return if ($dest eq undef);

   # Store
   if (ref $vars eq 'ARRAY') {
      if (@{$vars} != @{$vals}) {
         $error = "Number of variables and values differs";
         return;
      }
      for (my $i=0; $i < @{$vars}; $i++) {
         $dest->{$vars->[$i]} = $vals->[$i];
      }
   } else {
      $dest->{$vars} = $vals;
   }

   # Ok set mod-flag
   $self->{'modified'} = 1;
   return 1;
}

#------------
# Groups($;$)
#
# Returns a list with all sub-groups of a given group (undef=base)
#
# in:  [group(s)]
# out: Group-list (undef = failure)

sub Groups($;$)
{
   my ($self,$grp) = @_;

   # Get group-ref
   my $gbase = _Group($self->{'vars'},$grp);
   return if ($gbase eq undef);

   # Return list
   my @tmp = ();
   map { push(@tmp,$_) if (ref $gbase->{$_}); } keys %{$gbase};
   return @tmp;
}

#---------------
# GroupGet($$;$)
#
# Creates a variable-hash from all available groups
#
# in:  Variable[,group(s)]
# out: Hash{group} = value of the 'variable' in the 'group'

sub GroupGet($$;$)
{
   my ($self,$var,$grp) = @_;

   # Get group-ref
   my $data = _Group($self->{'vars'},$grp);
   return if ($data eq undef);

   # Collect values
   my %tmp = ();
   foreach (keys %{$data}) {
      $tmp{$_} = (exists $data->{$_}->{$var}) ? $data->{$_}->{$var} : ''
         if (ref $data->{$_});
   }
   return %tmp;
}


1;
__END__

#------------------
# POD-documentation

=head1 NAME

Configuration-management modul

=head1 FUNCTIONS

=head2 Note:

=item I<var(s)>   := A scalar for a single variable or a anon-array of a variables-list

=item I<group(s)> := Group-access - also scalar or anon-array

=head2 Functions:

=item I<new(config-filename)>

=item I<Open(config-filename)>

=item I<Save([config-filename])>

=item I<Get([var(s) [,group(s)]])>

=item I<Set(var(s),value(s) [group(s)])>

=item I<Groups([group(s)])>

=item I<GroupGet(variable [,group(s)])>

=head1 AUTHOR

Ravemax/Dextrose <ravemax@dextrose.com>

=cut
