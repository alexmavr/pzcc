#!/usr/bin/perl

use strict;

my $OBJDumpCmd  = 'objdump --version |';
my $LDasmConfig ='ldasm/ldasm.cfg';
my $CfgVariable = 'OBJDumpSize';

# Get OBJDump-version string
open(ODO, $OBJDumpCmd)
    or die "Failed to execute OBJDump - LDasm doesn't work w/o it : $!\n";
my $verStr = <ODO>;
close(ODO);

# Set variable-value depending on the objdump-version
$verStr =~ /(2\.(\d+)\.\d+)/;
print "objdump version: $1\n";
my $varValue = ($2 < 10) ? 'yes' : 'no';

# Check if variable is already set in the config-file, if not append
open(CFG, "+< $LDasmConfig")
    or die "File '$LDasmConfig' missing - corrupt archive ?\n";
while (<CFG>) {
    if (/^$CfgVariable/) {
        close(CFG);
        exit;
    }
}
print CFG "\n; Added by objdump_ver.pl\n",
          "$CfgVariable = $varValue\n";
close(CFG);
